package cours.m2gl.jee.api.hospital.model;

public enum RoleName {
    ROLE_CLIENT,
    ROLE_ADMIN
}
