package cours.m2gl.jee.api.hospital.model;

public enum RoleName {
    ROLE_ADMIN,
    ROLE_CLIENT
}
