package cours.m2gl.jee.api.hospital.model;

import java.io.Serializable;

public enum RoleName implements Serializable {
    ROLE_CLIENT,
    ROLE_ADMIN
}
